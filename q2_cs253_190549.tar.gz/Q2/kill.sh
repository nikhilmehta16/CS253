ps | grep timeout | awk '{print $1}' | xargs kill
