#!/bin/bash
./10ZmoZg3pWmw9aA < input1.txt &
./DFwAU7iSoYorHy8 < input2.txt &
./dUkeKOpRSOxQfx2 < input3.txt &

